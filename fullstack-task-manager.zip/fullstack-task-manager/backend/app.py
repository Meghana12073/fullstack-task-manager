from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_jwt_extended import JWTManager, jwt_required, create_access_token
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
import uuid

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'your-super-secret-key-for-internship-project'
app.config['JWT_SECRET_KEY'] = 'jwt-secret-key-change-in-production'

jwt = JWTManager(app)
CORS(app)

# In-memory storage for demo (replace with MongoDB later)
users_db = {}
profiles_db = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    user_id = str(uuid.uuid4())
    
    # Check if user exists
    if data['email'] in users_db:
        return jsonify({'error': 'User already exists'}), 400
    
    # Create user
    users_db[data['email']] = {
        'id': user_id,
        'username': data['username'],
        'email': data['email'],
        'mobile': data.get('mobile', ''),
        'password': generate_password_hash(data['password'])
    }
    
    return jsonify({'message': 'User created successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    user = users_db.get(data['email'])
    
    if user and check_password_hash(user['password'], data['password']):
        token = create_access_token(identity={'email': user['email'], 'id': user['id']})
        return jsonify({
            'token': token,
            'user': {'username': user['username'], 'email': user['email']}
        })
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/profiles', methods=['GET'])
@jwt_required()
def get_profiles():
    return jsonify([{
        '_id': str(p['id']),
        'username': p['username'],
        'email': p['email'],
        'mobile': p.get('mobile', ''),
        'created_at': p.get('created_at', '2026-02-13T12:00:00Z')
    } for p in profiles_db])

@app.route('/api/profiles', methods=['POST'])
@jwt_required()
def create_profile():
    data = request.json
    profile_id = str(uuid.uuid4())
    profile = {
        'id': profile_id,
        'username': data['username'],
        'email': data['email'],
        'mobile': data.get('mobile', ''),
        'created_at': datetime.datetime.utcnow().isoformat()
    }
    profiles_db.append(profile)
    return jsonify({
        '_id': profile_id,
        **profile
    }), 201

@app.route('/api/profiles/<profile_id>', methods=['DELETE'])
@jwt_required()
def delete_profile(profile_id):
    global profiles_db
    profiles_db = [p for p in profiles_db if p['id'] != profile_id]
    return jsonify({'message': 'Profile deleted'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
